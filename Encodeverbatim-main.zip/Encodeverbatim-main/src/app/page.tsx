"use client";

import SignUp from "@/app/Pages/SignUp/SignUp";

export default function Home() {
  return (
    <div>
      <SignUp />
    </div>
  );
}
