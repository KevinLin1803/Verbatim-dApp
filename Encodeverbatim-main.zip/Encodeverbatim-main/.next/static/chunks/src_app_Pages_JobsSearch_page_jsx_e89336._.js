(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_Pages_JobsSearch_page_jsx_e89336._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_Pages_JobsSearch_page_jsx_e89336._.js",
  "chunks": [
    "static/chunks/node_modules_34a36d._.js",
    "static/chunks/src_app_Pages_JobsSearch_c73a1a._.js"
  ],
  "source": "dynamic"
});
