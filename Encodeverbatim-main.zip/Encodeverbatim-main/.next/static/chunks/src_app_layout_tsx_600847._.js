(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_600847._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_600847._.js",
  "chunks": [
    "static/chunks/src_app_c7d265._.css",
    "static/chunks/src_app_layout_tsx_20a9fc._.js"
  ],
  "source": "dynamic"
});
