(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_Pages_Profile_page_jsx_e89336._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_Pages_Profile_page_jsx_e89336._.js",
  "chunks": [
    "static/chunks/node_modules_@mui_joy_8a8f4f._.js",
    "static/chunks/node_modules_@mui_746334._.js",
    "static/chunks/node_modules_@mui_material_df4e97._.js",
    "static/chunks/node_modules_@headlessui_react_dist_6414d8._.js",
    "static/chunks/node_modules_@floating-ui_react_dist_c1a64d._.js",
    "static/chunks/node_modules_cc0e5d._.js",
    "static/chunks/src_app_e75978._.js"
  ],
  "source": "dynamic"
});
